# Coffee One Love: one-click report
Only constructed states, counters and source/build identifiers. No screenshots, PIN, credentials, account files, raw logcat or raw API replies. Missing events do not prove success. Full command logs stay local. This archive does not contain its own Git delivery receipt.
